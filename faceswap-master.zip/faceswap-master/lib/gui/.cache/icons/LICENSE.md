Icons made by [smashicons](https://www.flaticon.com/authors/smashicons) from [www.flaticon.com](www.flaticon.com)

Colorized and adapted by @torzdf