********************
plaidml_utils module
********************

.. automodule:: lib.plaidml_utils
   :members:
   :undoc-members:
   :show-inheritance:
