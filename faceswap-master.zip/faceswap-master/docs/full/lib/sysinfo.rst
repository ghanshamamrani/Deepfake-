sysinfo module
==============

.. automodule:: lib.sysinfo
   :members:
   :undoc-members:
   :show-inheritance:
