*****************
serializer module
*****************

.. rubric:: Module Summary

.. autosummary::
   :nosignatures:
   
   ~lib.serializer.Serializer
   ~lib.serializer.get_serializer
   ~lib.serializer.get_serializer_from_filename

.. rubric:: Module

.. automodule:: lib.serializer
   :members:
   :undoc-members:
   :show-inheritance:
