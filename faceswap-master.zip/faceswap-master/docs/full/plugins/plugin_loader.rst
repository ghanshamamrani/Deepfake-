*********************
plugin\_loader module
*********************

.. automodule:: plugins.plugin_loader
   :members:
   :undoc-members:
   :show-inheritance:
