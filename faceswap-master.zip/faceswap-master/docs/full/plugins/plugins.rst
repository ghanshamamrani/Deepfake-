plugins package
===============

The plugins package holds Extraction, Training and Conversion plugins for Faceswap.

.. toctree::
   :glob:

   *

