************
sort package
************

.. contents:: Contents
   :local:


sort module
===========
The Sort Module is the main entry point into the Sort Tool.

.. automodule:: tools.sort.sort
   :members:
   :undoc-members:
   :show-inheritance:


sort_methods module
===================

.. automodule:: tools.sort.sort_methods
   :members:
   :undoc-members:
   :show-inheritance:


sort_methods_aligned module
===========================

.. automodule:: tools.sort.sort_methods_aligned
   :members:
   :undoc-members:
   :show-inheritance:
